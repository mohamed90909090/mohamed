$('.owl-carousel').owlCarousel({
    loop:true,
    dragEndSpeed:3000,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:1
        }
    }
})

$(document).ready (function () {
$(".loading").fadeOut (4000 , function() {
$("body").css ("overflow" , "auto")
})


})