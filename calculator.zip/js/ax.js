var h = 25

var m = true

var p = "hello mohamed"


//document.getElementById('gt').innerHTML = p
//console .log(p)
//window.alert(p)

//var name1 = prompt('enter your name')
//var name2 =  prompt('enter your name 2')

//var sam = name1 + name2
//window.alert(sam)
/*

//var lo =prompt('enter your name')

//if(lo =='mohamed')
{
    window.alert('hi')
}

else if (lo == 'nj')
{
    window.alert('false')
}



var mohamed =prompt('enter your name')
switch (mohamed) {
    case"front end" :
    window.alert('true')
break

case"back end" :
window.alert('false')
break

case"front nj" :
window.alert('rue')
break
default:"vgy"
window.alert('sorry')
}
*/


var x = 8 ;

var y = 'hello'

var z = true //false

var a =  2

var x = 10 

/*
var w = null
*/

/*
var y =  20 

var z = 2

var sum = x + y * z / 2

var f = false


var h =prompt('enter your name')

if (  h<50 )
{
    window.alert("middle")
}


else if ( h<0)
{
    window.alert("good")

}
else if (h<65)
{
    window.alert("good")

}
else if (h<80)
{
    window.alert("very good")

}
else if (h<90)
{
    window.alert("Ecxelant")

}
else if (h<100)
{
    window.alert("very Ecxelant")

}



/*
else if( x > 25)
{
    window.alert("middle")
}


else {
window.alert("sorry you do not write any thing")
}
 
for (var i =0;i<3;i++)
{
window.alert('hello')
}
*/
/*


while (i<10) {
    cartona+=
    i++
}
document.getElementById('mul').innerHTML = cartona

var cartona=''
var i=0
do{
    cartona+='<img src="img/Layer-3.png" alt="">'
    i++
}
while (i<10) 
document.getElementById('mul').innerHTML = cartona

var ki =
{
    price:20000 ,
    ad :10
    
}
function get (num1, num2)
{
var sum =num1 + num2
console.log(sum)
}
get(10 , 20)
get(20 , 20)
get(20 , 30)


function bu()
{
    window.alert("sorry")
}

/////////////////////////////////

 , "mohamed","gta" , "bassem",  "yasen" , "mohamed","gta" , "bassem",  "yasen" , "mohamed","gta" , "bassem",  "yasen" , "mohamed","gta" , "bassem",  "yasen" , "mohamed","gta" , "bassem",  "yasen" , "mohamed","gta"]

var names =["cfr", "gta", "bassem",  "yasen"] 
var hy =prompt ('enter your name')

names.push (hy)

for (var i =0; i<names.length; i++)
{
    console.log(names[i])

}
*/

